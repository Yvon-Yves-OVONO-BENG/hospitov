<?php

namespace App\Controller\TypeUtilisateur;

use App\Form\TypeUtilisateurType;
use App\Service\StrService;
use App\Repository\TypeUtilisateurRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Contracts\Translation\TranslatorInterface;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;


/**
 * @IsGranted("ROLE_USER", message="Accès refusé. Espace reservé uniquement aux abonnés")
 *
 */
#[Route('/typeUtilisateur')]
class ModifierTypeUtilisateurController extends AbstractController
{
    public function __construct(
        private StrService $strService,
        private EntityManagerInterface $em,
        private TranslatorInterface $translator,
        private TypeUtilisateurRepository $typeUtilisateurRepository,
    )
    {}

    #[Route('/modifier-typeUtilisateur/{slug}', name: 'modifier_typeUtilisateur')]
    public function modifierTypeUtilisateur(Request $request, string $slug): Response
    {
        # je récupère ma session
        $maSession = $request->getSession();
        
        #mes variables témoin pour afficher les sweetAlert
        $maSession->set('ajout', null);
        $maSession->set('misAjour', null);
        $maSession->set('suppression', null);
        
        

        #je récupère l'typeUtilisateur à modifier
        $typeUtilisateur = $this->typeUtilisateurRepository->findOneBySlug([
            'slug' => $slug
        ]);

        #je crée mon formulaire et je le lie à mon instance
        $form = $this->createForm(TypeUtilisateurType::class, $typeUtilisateur);

        #je demande à mon formulaire de récupérer les donnéesqui sont dans le POST avec la $request
        $form->handleRequest($request);

        #je fabrique mon slug
        $characts    = 'abcdefghijklmnopqrstuvwxyz#{};()';
        $characts   .= 'ABCDEFGHIJKLMNOPQRSTUVWXYZ#{};()';	
        $characts   .= '1234567890'; 
        $slug      = ''; 

        for($i=0;$i < 11;$i++) 
        { 
            $slug .= substr($characts,rand()%(strlen($characts)),1); 
        }

        #je teste si mon formulaire est soumis et valide
        if ($form->isSubmitted() && $form->isValid()) 
        {
            #je met le nom de la typeUtilisateur en CAPITAL LETTER
            $typeUtilisateur->setTypeUtilisateur($this->strService->strToUpper($typeUtilisateur->getTypeUtilisateur()))
                    ->setSlug($slug)
            ;

            # je prépare ma requête avec entityManager
            $this->em->persist($typeUtilisateur);

            #j'exécutebma requête
            $this->em->flush();

            #j'affiche le message de confirmation d'ajout
            $this->addFlash('info', $this->translator->trans('Type personnel mise à jour avec succès !'));

            #j'affecte 1 à ma variable pour afficher le message
            $maSession->set('misAjour', 1);
            
            #je retourne à la liste des typeUtilisateurs
            return $this->redirectToRoute('afficher_typeUtilisateur', [ 'm' => 1 ]);
        }

        # j'affiche mon formulaire avec twig
        return $this->render('typeUtilisateur/ajouterTypeUtilisateur.html.twig', [
            'slug' => $slug,
            'licence' => 1,
            'typeUtilisateur' => $typeUtilisateur,
            'formTypeUtilisateur' => $form->createView(),
            'dossier' => $this->translator->trans("Type personnel"),
            'route' => $this->translator->trans("Modification de : ").$typeUtilisateur->getTypeUtilisateur(),
        ]);
    }
}
